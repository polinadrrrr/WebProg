from django.urls import path, include
from rest_framework import routers

from api.v1.client.views import ArticleViewSet

router = routers.DefaultRouter()
router.register(r'users', UserViewSet)

urlpatterns = [
    path('', include(router.urls)),
]